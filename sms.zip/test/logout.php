<?php
session_start();
session_destroy();

?>
     <script>document.location.href = "login.php";</script>
    </html>