<!DOCTYPE html>
<html lang="en">

<head>

<?php

include "../include/head.php";

?>

</head>

<body class="theme-red">
<?php

include "../include/menu.php";

?>

<section>
	<section>
		
	</section>
</section>


<?php

include "../include/end.php";

?>

</body>

</html>